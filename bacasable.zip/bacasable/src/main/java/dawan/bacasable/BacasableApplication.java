package dawan.bacasable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BacasableApplication {

	public static void main(String[] args) {
		SpringApplication.run(BacasableApplication.class, args);
	}
}
